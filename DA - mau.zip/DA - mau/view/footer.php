<footer class="box_footer row mb">
      <div class="footer">
        <div class="footer-left">
          <div class="footer-logo">
            <img src="./image/2 1 (1).png" alt="" />
          </div>
          <div class="card_1">
            <h3>THƯƠNG HIỆU MỸ PHẨM SỐ 1 VIỆT NAM</h3>
            <div>
              <i class="fa-sharp fa-solid fa-location-pin"></i>
              <p>
                Tầng 2 tòa nhà T10, Times City Vĩnh Tuy, Hai Bà Trưng, Hà Nội.
              </p>
            </div>
  
            <div>
              <i class="fa-solid fa-phone-flip"></i>
              <p>1900.63.69.36</p>
            </div>
  
            <div>
              <i class="fa-solid fa-envelope"></i>
              <p>info@tocotocotea.com</p>
            </div>
            <div class="icons">
              <i class="fa-brands fa-facebook"></i>
              <i class="fa-brands fa-square-instagram"></i>
              <i class="fa-brands fa-youtube"></i>
              <i class="fa-brands fa-square-twitter"></i>
              <i class="fa-brands fa-google-plus"></i>
            </div>
  
            <div class="images">
              <div class="image4">
                <img
                  src="./image/home_hotdeal_3_grande.webp"
                  alt=""
                />
              </div>
              <div class="image4">
                <img src="./image/home_hotdeal_4_grande.webp" alt="" />
              </div>
            </div>
  
            <div class="image_3 image4">
              <img src="./image/home_slider_5_d_master.jpg" alt="" />
            </div>
          </div>
        </div>
        <div class="footer-right">
          <div class="card_2">
            <h3>VỀ CHÚNG TÔI</h3>
            <a href="#">Giới thiệu về Cherry</a>
            <a href="#">Nhượng quyền</a>
            <a href="">Tin tức khuyến mại</a>
            <a href="">Cửa hàng</a>
            <a href="#">Quy định chung</a>
            <a href="#">TT liên hệ</a>
          </div>
          <div class="card_3">
            <h3>CHÍNH SÁCH</h3>
            <a href="#">Chính sách thành viên</a>
            <a href="#">Hình thức thanh toán</a>
            <a href="#">Vận chuyển giao nhận</a>
            <a href="#">Đổi trả và hoàn tiền</a>
            <a href="#">Bảo vệ thông tin cá nhân</a>
            <a href="#">Bảo trì, bảo hành</a>
          </div>
        </div>
      </div>
      </footer>
    </div>
    <script src="main.js"></script>
  </body>
</html>
