<main class="row">
        <div class="row frmtitle"><h1>DANH SÁCH LOẠI HÀNG</h1></div>
        <div class="row frmcontent">
          <form action="#" method="post">
            <div class="row mb10 frmdsloai">
              <table>
                <tr>
                  <th></th>
                  <th>MÃ LOẠI</th>
                  <th>TÊN LOẠI</th>
                  <th></th>
                </tr>
                <tr>
                  <td><input type="checkbox" name="" id="" /></td>
                  <td>001</td>
                  <td>Son môi</td>
                  <td>
                    <input type="button" value="Sửa" />
                    <input type="button" value="Xóa" />
                  </td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="" id="" /></td>
                  <td>001</td>
                  <td>Son môi</td>
                  <td>
                    <input type="button" value="Sửa" />
                    <input type="button" value="Xóa" />
                  </td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="" id="" /></td>
                  <td>001</td>
                  <td>Son môi</td>
                  <td>
                    <input type="button" value="Sửa" />
                    <input type="button" value="Xóa" />
                  </td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="" id="" /></td>
                  <td>001</td>
                  <td>Son môi</td>
                  <td>
                    <input type="button" value="Sửa" />
                    <input type="button" value="Xóa" />
                  </td>
                </tr>
              </table>
            </div>
            <div class="row mb10">
              <input type="button" value="Chọn tất cả" />
              <input type="button" value="Bỏ chọn tất cả" />
              <input type="button" value="Xóa các mục đã chọn" />
              <a href="./admin.html"
                ><input type="button" value="Nhập thêm"
              /></a>
            </div>
          </form>
        </div>
      </main>
    </div>