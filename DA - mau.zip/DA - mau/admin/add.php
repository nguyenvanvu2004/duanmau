<main class="row">
        <div class="row frmtitle"><h1>THÊM MỚI LOẠI HÀNG</h1></div>
        <div class="row frmcontent">
          <form action="#" method="post">
            <div class="row mb10">
              Mã loại<br />
              <input type="text" name="maloai" disabled />
            </div>
            <div class="row mb10">
              Tên loại<br />
              <input type="text" name="tenloai" />
            </div>
            <div class="row mb10">
              <input type="submit" value="Thêm mới" />
              <input type="reset" value="Nhập lại" />
              <a href="./danhsach_loaihang.html"
                ><input type="button" value="Danh sách"
              /></a>
            </div>
          </form>
        </div>
      </main>
    </div>